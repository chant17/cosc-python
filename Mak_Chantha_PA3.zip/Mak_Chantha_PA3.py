import turtle

myTurtle = turtle.Turtle()
turtle.setup(800, 600)
myWin = turtle.Screen()
myTurtle.hideturtle()
myWin.title("UH logo")


def draw_U(posx,posy,color):  # a fuction that will draw the shape of letter "U"
    myTurtle.penup()    # I used penup and pen down so that no marks will be present whenever i move the position of the letter
    myTurtle.setpos(posx, posy)  # i use this function to set the position of the letter "U" to the top left corner
    myTurtle.pendown()
    myTurtle.begin_fill()  # this function is needed in order for the letter "U" to start filling in color.
    myTurtle.forward(60 / 2)
    myTurtle.left(45)
    myTurtle.forward(20)
    myTurtle.left(45)
    myTurtle.forward(75)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.left(90)
    myTurtle.forward(20)
    myTurtle.left(90)
    myTurtle.forward(35)
    myTurtle.left(90)
    myTurtle.forward(20)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(75-10)
    myTurtle.right(45)
    myTurtle.forward(7)
    myTurtle.right(45)
    myTurtle.forward(60-14)
    myTurtle.right(45)
    myTurtle.forward(7)
    myTurtle.right(45)
    myTurtle.forward(75-10)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.left(90)
    myTurtle.forward(20)
    myTurtle.left(90)
    myTurtle.forward(35)
    myTurtle.left(90)
    myTurtle.forward(20)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(75)
    myTurtle.left(45)
    myTurtle.forward(20)
    myTurtle.left(45)
    myTurtle.forward(60)
    myTurtle.fillcolor(color)  # i use this function to choose preferred color
    myTurtle.end_fill()  # with end_fill, the function will apply the preferred color

def draw_H(posx,posy,color):  # this function is responsible for letter "H"
    myTurtle.penup()
    myTurtle.setpos(posx-15, posy-10)  # i use this function to set the position of the letter "H"
    myTurtle.pendown()
    myTurtle.begin_fill() #start to fill
    myTurtle.left(90)
    myTurtle.forward(60+5)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(35)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.left(90)
    myTurtle.forward(15)
    myTurtle.left(90)
    myTurtle.forward(60)
    myTurtle.left(90)
    myTurtle.forward(15)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(35)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.left(90)
    myTurtle.forward(60)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(35)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.left(90)
    myTurtle.forward(30)
    myTurtle.left(90)
    myTurtle.forward(60)
    myTurtle.left(90)
    myTurtle.forward(30)
    myTurtle.left(90)
    myTurtle.forward(7)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(35)
    myTurtle.right(90)
    myTurtle.forward(20)
    myTurtle.right(90)
    myTurtle.forward(7)
    myTurtle.fillcolor(color)
    myTurtle.end_fill() # end the fill and apply the preferred color

def draw_UH(posx,posy,color): # this function will combine function draw_U and draw_H
    draw_U(posx,posy,color)
    draw_H(posx,posy,color)


def draw_grid(posx,posy,rows,cols):
    for a in range(rows): # i used nested loop to print out UH in a numbers of rows and columns
        for b in range(cols):
            draw_UH(posx,posy, "black")
            posx += 180 # this is used to move the position of my letters forward by 180 pixels
        posy -= 180 # set back y to original position
        posx = -325 # set back x to original position



myTurtle.speed(0) # this object will set the speed of print
draw_grid(-325,180,3,4) # calling function draw_grid to action and apply position to x,y and numbers of rows and colums
myTurtle.pencolor("black")
myWin.exitonclick() # this will only allow the program to exit whenever the user click

