'''
    Original Program Explanation:
    - The program shows how we can use our turtle to generate a fractal tree using recursion. The prgram make use of
      recursion by using "tree(branchLen-15, t). The program check if the branch length is bigger than 5. If so, the
      turtle will turn right. The recursion are made right after the turtle turns right 20 degree.
      The program makes another recursive call after it turns left by 40 degree. The turtle needed to turn left 40 degrees
      in order to undo the 20 degree right and add an addition 20 degree left to draw the other branch. Moreover, each time
      the program make a recursive call to tree branch parameter will be substract by 15 to make the branch get progressively
      smaller until it hit 0. Calling main() to action at the end will allow the program to create a symmetrical recursive
      tree
'''

import turtle

def tree(branchLen,t):
    t.pensize(branchLen/10) # progressively changing the size of the branch throughout the recursion process

    if branchLen < 35:
        t.color("green") # when the branch length reach a certain number, the branch will change color
    else:
        t.color("brown")

    if branchLen > 5:
        t.forward(branchLen)
        t.right(20)
        tree(branchLen -15,t)
        t.left(40)
        tree(branchLen -15,t)
        t.right(20)
        t.penup()
        t.backward(branchLen+1.5) # my adding 1.5 whenever it go backward, the tree will be less symmetrical
        t.left(.15) # slightly change the angle of the branch whenever it go backward so that the branch will remained attached
        t.pendown()
    else:
        if branchLen == 0: # when the branch length reaches its smallest point, there will be circular leaves
            t.shape("circle") # change the shape of the turtle to a circle whenever the length reaches 0.
            t.pencolor("green")
            t.fillcolor("white")
            t.stamp() # this will stamp whatever shape of the turtle that i assigned
                      # alternate way to do the circular leaf would be t.circle() but the leaves won't be centralized

def main():
    window = turtle.Screen()
    t= turtle.Turtle()
    t.left(90)
    t.color('green')
    t.penup()
    t.setpos(0, -250) # change the starting position of my recursion tree
    t.pendown()
    t.speed(0)
    tree(90,t)

    window.exitonclick() # only exit whenver the user click

main() # calling the whole program to action